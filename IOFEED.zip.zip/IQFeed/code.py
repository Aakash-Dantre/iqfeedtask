import pytz
from iqfeed import get_bars
from datetime import datetime
import time
import pymysql
import os
# from subprocess import call
# call("IQConnect.exe -u 486484 -p 80403631 -version 6.1.0.20 -product STEFAN_CHYTRA_43684 -autoconnect")
# os.system("IQConnect.exe -u 486484 -p 80403631 -version 6.1.0.20 -product STEFAN_CHYTRA_43684 -autoconnect;")
instruments = []
with open("../SPX_tickers.csv", encoding='utf-8-sig') as f:
    for ins in f:
        instruments.append(ins[:-1].split(','))

# print(instruments)
time = []
with open("../SPXshedule.csv", encoding='utf-8-sig') as f:
    for ins in f:
        temp = ins[:-1].split(',')
        if len(temp[0]) == 4:
            time.append(['0'+temp[0], temp[1]])
        else:
            time.append(temp)
# print(time)
tz = pytz.timezone('US/Eastern')
# print(datetime.now())
# print(datetime.now(pytz.utc))
# print(datetime.strptime(time[-1][0],'%H:%M') > datetime.now());
# //print(datetime.strptime(time[0][0], '%H:%M'))
# //print(str(datetime.now(pytz.utc).time())[0:5])
#print()
bars = get_bars(instruments)
print(bars);
exit()
while True:
    worktime = -1
    for i in range(len(time)):
        if i != len(time) - 1 and time[i][0] < str(datetime.now(pytz.utc).time())[0:5] < time[i+1][0]:
            worktime = i
    print(worktime)
    if worktime == -1:
        1

    bars = get_bars(instruments)


    #database
    #setup
    try:
        cnx = pymysql.connect(user='aakash', password='incorect',host='127.0.0.1',cursorclass=pymysql.cursors.DictCursor)
        cur=cnx.cursor()
        try:
            cur.execute("CREATE DATABASE IF NOT EXISTS SPXdata;")
            cur.execute("use SPXdata;")
            cnx.commit()
            try:
                cur.execute("CREATE TABLE Data(Ts datetime PRIMARY KEY,Ticker int PRIMARY KEY,Symbol varchar(30),Bid float,Ask float,Volatility float); ")
            except:
                print("lol")
            print("done")
        except Exception as e:
            print(e)
    except Exception as e:
        print(e)

    for i in bars:
        ticker =i[0]
        sym =i[1]
        ts =i[2]
        bid =i[3]
        ask =i[4]
        vol =i[5]
        cur.execute("INSERT INTO Data values('{}',{},'{}',{},{},{})".format(ts, ticker, sym, bid, ask,  vol))
        cnx.commit()

    while str(datetime.now(pytz.utc).time())[0:5] < time[i+1]:
        time.sleep(1)
    cnx.close()
