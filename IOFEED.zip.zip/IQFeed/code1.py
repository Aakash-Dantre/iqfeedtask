import pytz
from iqfeed import get_vix
from datetime import datetime
import time
import pymysql
import os
import socket
import contextlib
import subprocess
# IQConnect.exe -u 486484 -p 80403631 -version 6.1.0.20 -product STEFAN_CHYTRA_43684 -autoconnect;
# subprocess.call("timeout 10", shell=True)
# os.spawnl("IQConnect.exe -u 486484 -p 80403631 -version 6.1.0.20 -product STEFAN_CHYTRA_43684 -autoconnect;")
os.spawnl("IQConnect.exe -u 486484 -p 80403631 -version 6.1.0.20 -product STEFAN_CHYTRA_43684 -autoconnect;")
print("Hey")
contextlib.closing(socket.create_connection(('localhost', 5009)))
# instruments = []
# with open("../VIXfut.csv", encoding='utf-8-sig') as f:
#     for ins in f:
#         instruments.append([datetime.strptime(ins[:-1].split(',')[0]+'AM', '%d/%m/%Y %I:%M%p'), ins[:-1].split(',')[1]])
# tz = pytz.timezone('US/Eastern')
# if datetime.strftime(instruments[0][0],"%Y/%m/%d %I:%M%p") < datetime.strftime(datetime.now(pytz.utc), "%Y/%m/%d %I:%M%p"):
#     instruments = instruments[1:]
# # tz = pytz.timezone('US/Eastern')
# print(datetime.strptime(instruments[0][0], '%d/%m/%Y %I:%M%p'))
# print(tz.localize(instruments[0][0]));
# bars = get_vix(instruments)
# print(bars)
#database
    #setup
try:
    cnx = pymysql.connect(user='aakash', password='incorect',host='127.0.0.1',cursorclass=pymysql.cursors.DictCursor)
    cur = cnx.cursor()
    try:
        cur.execute("CREATE DATABASE IF NOT EXISTS VIXtable;")
        cur.execute("use VIXtable;")
        cnx.commit()
        try:
            cur.execute("CREATE TABLE Data(TimeStamp varchar(30),SecurityNo int,Symbol varchar(30),ExpiryDate varchar(25),Bid float,Ask float,PRIMARY KEY (TimeStamp,SecurityNo));")
        except Exception as e:
            print(e)
            print("delete the table Data if schema is not same")
        print("done")
    except Exception as e:
        print(e)
except Exception as e:
    print(e)

# print(str(datetime.now(pytz.utc).time())[6:8])
time.sleep(60 - int(str(datetime.now(pytz.utc).time())[6:8]))
print("After time")

while True:
    if datetime.now(pytz.utc).weekday() >= 4:
        if datetime.now(pytz.utc).weekday() == 6:
            while datetime.strftime(datetime.now(pytz.utc), "%I") < "17":
                time.sleep(60)
        elif datetime.now(pytz.utc).weekday() == 4:
            if datetime.strftime(datetime.now(pytz.utc), "%I") > "16":
                time.sleep(600)
                continue
        else:
            time.sleep(600)
            continue
    instruments = []
    with open("../VIXfut.csv", encoding='utf-8-sig') as f:
        for ins in f:
            instruments.append(
                [datetime.strptime(ins[:-1].split(',')[0] + 'AM', '%d/%m/%Y %I:%M%p'), ins[:-1].split(',')[1]])
    tz = pytz.timezone('US/Eastern')
    if datetime.strftime(instruments[0][0], "%Y/%m/%d %I:%M%p") < datetime.strftime(datetime.now(pytz.utc),
                                                                                    "%Y/%m/%d %I:%M%p"):
        instruments = instruments[1:]
    while  "15:15" < str(datetime.now(pytz.utc).time())[0:5] < "15:30":
        time.sleep(10)
    while True:
        currtime = datetime.strftime(datetime.now(pytz.utc), "%Y/%m/%d %I:%M%p")
        if "15:15" < str(datetime.now(pytz.utc).time())[0:5] < "15:30":
            break;
        bars = get_vix(instruments)
        print(bars)
        for i in range(8):
            secid = i
            ts = currtime
            sym = instruments[i][1]
            bid = float(bars[i][1])
            ask = float(bars[i][0])
            expdate = datetime.strftime(instruments[i][0], "%Y/%m/%d %I:%M%p")
            query="INSERT INTO Data values('{}',{},'{}','{}',{},{})".format(ts, secid, sym,expdate, bid, ask)
            print(query)
            try:cur.execute(query)
            except Exception as e: print(e)

        cnx.commit()
        # print(60 - int(str(datetime.now(pytz.utc).time())[6:7]))
        time.sleep(60 - int(str(datetime.now(pytz.utc).time())[6:8]))
        if datetime.now(pytz.utc).weekday() == 4:
            if datetime.strftime(datetime.now(pytz.utc), "%I") > "16":
                break