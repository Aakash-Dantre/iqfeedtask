# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

import socket
import contextlib
from collections import namedtuple
from datetime import datetime
import logging

from backports.functools_lru_cache import lru_cache

from .tools import retry

log = logging.getLogger(__name__)

Bar = namedtuple('IQFeedBar', ['datetime', 'open', 'high', 'low', 'close', 'volume'])


def __download_historical_data(ins, iqfeed_socket, chunk_size=4096):
    """
    Read the data from iqfeed_socket with the given chunk size.
    The collected data is returned as a string or exception is raised on error
    """
    buffer_ = []
    chunk = ""
    # end_msg = '\n!ENDMSG!,\r\n'
    end_msg = 'MSG!,\r\n'
    # print(iqfeed_socket.recv(chunk_size).decode())
    while not chunk.endswith(end_msg):
        chunk = iqfeed_socket.recv(chunk_size).decode()
        print(chunk)
        if chunk.startswith('E,'):  # Error condition
            if chunk.startswith('E,!NO_DATA!'):
                buffer_ = [ins[0], ins[2], '', '', '']
                log.warn('No data available for the given instrument')
                break
            else:
                raise Exception(chunk)
        log.debug('New chunk: %s', " ".join("{:02x}".format(ord(c)) for c in chunk[-1*len(end_msg):]))
        # if len(chunk.split(',')) > 5:
            # buffer_ = [ins[0], ins[2], chunk.split(',')[1], chunk.split(',')[4], chunk.split(',')[5]]

    return buffer_


def __get_diff( iqfeed_socket, chunk_size=4096):
    chunk = ""
    end_msg = 'MSG!,\r\n'
    val = 0
    while not chunk.endswith(end_msg):
        chunk = iqfeed_socket.recv(chunk_size).decode()
        if chunk.startswith('E,'):  # Error condition
            if chunk.startswith('E,!NO_DATA!'):
                val = ''
                break
            else:
                raise Exception(chunk)
        if len(chunk.split(',')) > 5:
            val = float(chunk.split(',')[2])-float(chunk.split(',')[3])
    return val


def __get_V(iqfeed_socket, chunk_size=4096):
    chunk = ""
    val = []
    while chunk == "" or chunk[0] != 'F':
        chunk = iqfeed_socket.recv(chunk_size).decode()
        if chunk[0] == 'F':
            # print(chunk)
            chunk = chunk.split('\n')[1]
            # print(chunk.split(','))
            try:
                val = [chunk.split(',')[3], chunk.split(',')[10]]
            except:
                chunk = iqfeed_socket.recv(chunk_size).decode()
                val = [chunk.split(',')[3], chunk.split(',')[10]]
            break
        if chunk.startswith('E,'):  # Error condition
            if chunk.startswith('E,!NO_DATA!'):
                val = []
                break
            else:
                raise Exception(chunk)
    return val

@lru_cache(maxsize=780000)  # 10 years worth of datetimes
def __create_datetime(datetime_str, format_str, timezone):
    # It takes a reasonable amount of time to construct the datetime fields with timezone info.
    # This function is used to cache the datetime object results.
    dt = datetime.strptime(datetime_str, format_str)
    return timezone.localize(dt)


# @retry(5, delay=2)
def get_vix(instruments):
    iqfeed_host = "localhost"
    data = []
    with contextlib.closing(socket.create_connection((iqfeed_host, 5009))) as iqfeed_socket:
        # iqfeed_socket.sendall(str.encode('S,SELECT UPDATE FIELD,Bid,Ask\n'))
        # __get_V(iqfeed_socket)
        for i in instruments:
            iqfeed_socket.settimeout(60)
            if i[1] != '':
                iqfeed_socket.sendall(str.encode('w'+i[1]+'\n'))
                temp = __get_V(iqfeed_socket)
                data.append(temp)
                iqfeed_socket.sendall(str.encode('r' + i[1] + '\n'))
    return data


def get_bars(instruments, timeout=60):
    """
    Returns list of Bar instances for the given instrument, time period, time zone and bar frequency (second_per_bar).
    The function is retried 5 times in 5 second intervals to alleviate IQFeed daemon's glitches.
    """
    # IQFeed accepts messages in the following format:
    #   CMD,SYM,[options]\n.
    # Notice the newline character. This must be added otherwise the request will not work.
    # The provided options are
    #   [second_per_bar],[beginning date: CCYYMMDD HHmmSS],[ending date: CCYYMMDD HHmmSS],[empty],
    #   [beginning time filter: HHmmSS],[ending time filter: HHmmSS],[old or new: 0 or 1],[empty],
    #   [second per data point].
    #
    # Source: https://github.com/bwlewis/iqfeed/blob/master/man/HIT.Rd
    iqfeed_host = "localhost"
    data = []
    with contextlib.closing(socket.create_connection((iqfeed_host, 9100))) as iqfeed_socket:
        for i in instruments[2:]:
            iqfeed_socket.settimeout(60)
            # Send the historical data request historical_data_request and buffer the data
            # print("HIT");
            # iqfeed_socket.sendall(historical_data_request)
            # data = __download_historical_data(iqfeed_socket)
            # print("HTX");
            # iqfeed_socket.sendall(str.encode("w"+instrument+"\n"))
            # iqfeed_socket.sendall((str.encode("S,SELECT UPDATE FIELD,Ask,Bid\n")))
            # print(i[2])
            if i[2] != '':
                iqfeed_socket.sendall(str.encode('HTX,'+i[2]+',1\n'))
                temp = __download_historical_data(i, iqfeed_socket)
                iqfeed_socket.sendall(str.encode('HIX,'+i[2]+',60,1\n'))
                val = __get_diff(iqfeed_socket)
                if val == '':
                    temp[2] = ''
                else:
                    temp[2] = str(val/float(temp[2]))
                # print(iqfeed_socket.recv(8192).decode())
                # print(iqfeed_socket.recv(4096).decode())
                data.append(temp)
            #   iqfeed_socket.sendall(str.encode("f"+instrument))
            # data = __download_historical_data(iqfeed_socket)

    return data
