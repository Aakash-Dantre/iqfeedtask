import pymysql
try:
    cnx = pymysql.connect(user='aakash', password='incorect',host='127.0.0.1',cursorclass=pymysql.cursors.DictCursor)
    cur=cnx.cursor()
    try:
        cur.execute("CREATE DATABASE SPXtable;")
        cur.execute("use SPXtable;")
        cnx.commit()
        cur.execute("CREATE TABLE Data(Ts datetime PRIMARY KEY,Ticker int,Symbol varchar(30),Bid float,Ask float,Volatility float); ")
        print("done")
    except Exception as e:
        print(e)
except Exception as e:
    print(e)



# for i in bars:
#     ticker =
#     sym =
#     ts =
#     bid =
#     ask =
#     vol =
#     cur.execute("INSERT INTO Data values('{}',{},'{}',{},{},{})".format(ts,ticker,sym,bid,ask,vol))
#     cnx.commit()

cnx.close()
